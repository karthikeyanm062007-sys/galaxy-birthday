import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface PlanetData {
  name: string;
  radius: number;
  distance: number;
  color: number;
  emissive: number;
  orbitSpeed: number;
  rotationSpeed: number;
  poem: string;
  hasRings?: boolean;
  ringColor?: number;
}

const planetsData: PlanetData[] = [
  {
    name: 'Mercury',
    radius: 0.4,
    distance: 10,
    color: 0x8c8c8c,
    emissive: 0x2a2a2a,
    orbitSpeed: 0.008,
    rotationSpeed: 0.004,
    poem: "Through every laugh and every cheer you stayed,\nThank you, my friends, for making my world brighter. ✨"
  },
  {
    name: 'Venus',
    radius: 0.6,
    distance: 14,
    color: 0xffd27f,
    emissive: 0x806840,
    orbitSpeed: 0.006,
    rotationSpeed: 0.003,
    poem: "Not every treasure shines like gold above,\nSome arrive as friends and stay as love. 💙"
  },
  {
    name: 'Earth',
    radius: 0.65,
    distance: 18,
    color: 0x4a90d9,
    emissive: 0x1a3050,
    orbitSpeed: 0.005,
    rotationSpeed: 0.01,
    poem: "Every wish you shared became a light,\nMaking my day feel warm and bright. 🌟"
  },
  {
    name: 'Mars',
    radius: 0.5,
    distance: 22,
    color: 0xc1440e,
    emissive: 0x602010,
    orbitSpeed: 0.004,
    rotationSpeed: 0.009,
    poem: "The best gift I received wasn't wrapped with a bow,\nIt was your kindness, friendship, and love you show. 💖"
  },
  {
    name: 'Jupiter',
    radius: 1.4,
    distance: 30,
    color: 0xd4a574,
    emissive: 0x6a523b,
    orbitSpeed: 0.002,
    rotationSpeed: 0.015,
    poem: "Life gave me countless reasons to smile today,\nBecause friends like you were there every step of the way. 🌸"
  },
  {
    name: 'Saturn',
    radius: 1.2,
    distance: 38,
    color: 0xf4d59e,
    emissive: 0x7a6b4f,
    orbitSpeed: 0.0015,
    rotationSpeed: 0.012,
    poem: "Stars may fade when morning is near,\nBut true friends remain forever dear. 🌙",
    hasRings: true,
    ringColor: 0xc9b896
  },
  {
    name: 'Uranus',
    radius: 0.9,
    distance: 45,
    color: 0x72d5d5,
    emissive: 0x3a6b6b,
    orbitSpeed: 0.001,
    rotationSpeed: 0.008,
    poem: "Some friendships are written beyond time and space,\nForever remembered, forever embraced. ✨"
  },
  {
    name: 'Neptune',
    radius: 0.85,
    distance: 52,
    color: 0x4b70dd,
    emissive: 0x25386e,
    orbitSpeed: 0.0008,
    rotationSpeed: 0.007,
    poem: "Every wish you sent became a part of my heart,\nThank you, my friends, for making my birthday a beautiful start. 💜"
  }
];

const sunPoem = "Friends like you turned moments into memories,\nAnd my heart will always smile because of you. ❤️";

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedPlanet, setSelectedPlanet] = useState<PlanetData | null>(null);
  const [showSunPoem, setShowSunPoem] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 2000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    containerRef.current.appendChild(renderer.domElement);

    // Create starfield
    const starsGeometry = new THREE.BufferGeometry();
    const starCount = 15000;
    const positions = new Float32Array(starCount * 3);
    const colors = new Float32Array(starCount * 3);
    const sizes = new Float32Array(starCount);

    for (let i = 0; i < starCount; i++) {
      const radius = 300 + Math.random() * 700;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);

      const colorChoice = Math.random();
      if (colorChoice < 0.3) {
        colors[i * 3] = 1;
        colors[i * 3 + 1] = 0.9;
        colors[i * 3 + 2] = 0.8;
      } else if (colorChoice < 0.6) {
        colors[i * 3] = 0.8;
        colors[i * 3 + 1] = 0.9;
        colors[i * 3 + 2] = 1;
      } else {
        colors[i * 3] = 1;
        colors[i * 3 + 1] = 1;
        colors[i * 3 + 2] = 1;
      }

      sizes[i] = Math.random() * 2 + 0.5;
    }

    starsGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    starsGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    starsGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    const starsMaterial = new THREE.PointsMaterial({
      size: 1.5,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
      sizeAttenuation: true
    });

    const stars = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(stars);

    // Create nebula effect with multiple layers
    const nebulaGeometry = new THREE.BufferGeometry();
    const nebulaCount = 5000;
    const nebulaPositions = new Float32Array(nebulaCount * 3);
    const nebulaColors = new Float32Array(nebulaCount * 3);

    for (let i = 0; i < nebulaCount; i++) {
      const radius = 100 + Math.random() * 400;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      nebulaPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      nebulaPositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      nebulaPositions[i * 3 + 2] = radius * Math.cos(phi);

      const colorChoice = Math.random();
      if (colorChoice < 0.33) {
        nebulaColors[i * 3] = 0.2;
        nebulaColors[i * 3 + 1] = 0.1;
        nebulaColors[i * 3 + 2] = 0.4;
      } else if (colorChoice < 0.66) {
        nebulaColors[i * 3] = 0.1;
        nebulaColors[i * 3 + 1] = 0.15;
        nebulaColors[i * 3 + 2] = 0.35;
      } else {
        nebulaColors[i * 3] = 0.15;
        nebulaColors[i * 3 + 1] = 0.08;
        nebulaColors[i * 3 + 2] = 0.25;
      }
    }

    nebulaGeometry.setAttribute('position', new THREE.BufferAttribute(nebulaPositions, 3));
    nebulaGeometry.setAttribute('color', new THREE.BufferAttribute(nebulaColors, 3));

    const nebulaMaterial = new THREE.PointsMaterial({
      size: 8,
      vertexColors: true,
      transparent: true,
      opacity: 0.15,
      sizeAttenuation: true
    });

    const nebula = new THREE.Points(nebulaGeometry, nebulaMaterial);
    scene.add(nebula);

    // Create Sun
    const sunGeometry = new THREE.SphereGeometry(4, 64, 64);
    const sunMaterial = new THREE.MeshBasicMaterial({
      color: 0xffdd44,
      transparent: true,
      opacity: 1
    });
    const sun = new THREE.Mesh(sunGeometry, sunMaterial);
    sun.name = 'Sun';
    scene.add(sun);

    // Sun glow layers
    for (let i = 0; i < 4; i++) {
      const glowGeometry = new THREE.SphereGeometry(4 + (i + 1) * 0.8, 32, 32);
      const glowMaterial = new THREE.MeshBasicMaterial({
        color: 0xffaa22,
        transparent: true,
        opacity: 0.15 - i * 0.03
      });
      const glow = new THREE.Mesh(glowGeometry, glowMaterial);
      sun.add(glow);
    }

    // Sun corona
    const coronaMaterial = new THREE.SpriteMaterial({
      color: 0xffcc66,
      transparent: true,
      opacity: 0.4
    });
    const corona = new THREE.Sprite(coronaMaterial);
    corona.scale.set(20, 20, 1);
    sun.add(corona);

    // Point light from sun
    const sunLight = new THREE.PointLight(0xffeedd, 2, 200);
    sun.add(sunLight);

    // Ambient light
    const ambientLight = new THREE.AmbientLight(0x222244, 0.3);
    scene.add(ambientLight);

    // Create planets
    const planets: THREE.Mesh[] = [];
    const planetGroups: THREE.Group[] = [];

    planetsData.forEach((planetData, index) => {
      const group = new THREE.Group();

      const geometry = new THREE.SphereGeometry(planetData.radius, 64, 64);
      const material = new THREE.MeshStandardMaterial({
        color: planetData.color,
        emissive: planetData.emissive,
        emissiveIntensity: 0.3,
        roughness: 0.8,
        metalness: 0.1
      });
      const planet = new THREE.Mesh(geometry, material);
      planet.name = planetData.name;
      planet.userData = { poem: planetData.poem, index };

      planet.position.x = planetData.distance;

      // Add rings for Saturn
      if (planetData.hasRings) {
        const ringGeometry = new THREE.RingGeometry(planetData.radius * 1.4, planetData.radius * 2.2, 64);
        const ringMaterial = new THREE.MeshBasicMaterial({
          color: planetData.ringColor,
          transparent: true,
          opacity: 0.6,
          side: THREE.DoubleSide
        });
        const rings = new THREE.Mesh(ringGeometry, ringMaterial);
        rings.rotation.x = Math.PI / 2.5;
        planet.add(rings);
      }

      // Add subtle glow to planets
      const glowGeometry = new THREE.SphereGeometry(planetData.radius * 1.15, 32, 32);
      const glowMaterial = new THREE.MeshBasicMaterial({
        color: planetData.color,
        transparent: true,
        opacity: 0.15
      });
      const glow = new THREE.Mesh(glowGeometry, glowMaterial);
      planet.add(glow);

      group.add(planet);
      scene.add(group);

      planets.push(planet);
      planetGroups.push(group);
    });

    // Create orbit paths
    planetsData.forEach(planetData => {
      const orbitGeometry = new THREE.BufferGeometry();
      const segments = 128;
      const orbitPositions = new Float32Array(segments * 3);

      for (let i = 0; i < segments; i++) {
        const angle = (i / segments) * Math.PI * 2;
        orbitPositions[i * 3] = Math.cos(angle) * planetData.distance;
        orbitPositions[i * 3 + 1] = 0;
        orbitPositions[i * 3 + 2] = Math.sin(angle) * planetData.distance;
      }

      orbitGeometry.setAttribute('position', new THREE.BufferAttribute(orbitPositions, 3));

      const orbitMaterial = new THREE.LineBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.08
      });

      const orbit = new THREE.LineLoop(orbitGeometry, orbitMaterial);
      scene.add(orbit);
    });

    camera.position.set(0, 40, 70);
    camera.lookAt(0, 0, 0);

    // Raycaster for click detection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onClick = (event: MouseEvent) => {
      mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
      mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      // Check sun
      const sunIntersects = raycaster.intersectObject(sun);
      if (sunIntersects.length > 0) {
        setSelectedPlanet(null);
        setShowSunPoem(true);
        return;
      }

      // Check planets with detailed traversal
      const planetMeshes: THREE.Object3D[] = [];
      planetGroups.forEach(group => {
        group.traverse(child => {
          if (child instanceof THREE.Mesh) {
            planetMeshes.push(child);
          }
        });
      });

      const intersects = raycaster.intersectObjects(planetMeshes, true);
      if (intersects.length > 0) {
        // Find the planet parent (could be a glow mesh or ring)
        let clickedObject = intersects[0].object;
        let planetName = '';

        // Check if clicked object has userData with poem
        if (clickedObject.userData && clickedObject.userData.poem) {
          planetName = clickedObject.name;
        } else {
          // Walk up the parent chain to find the planet
          let parent = clickedObject.parent;
          while (parent) {
            if (parent.name && planetsData.find(p => p.name === parent.name)) {
              planetName = parent.name;
              break;
            }
            parent = parent.parent;
          }
        }

        // If still no name, check the main planet meshes directly
        if (!planetName) {
          for (const planet of planets) {
            if (planet === clickedObject || planet.children.includes(clickedObject)) {
              planetName = planet.name;
              break;
            }
          }
        }

        const planetInfo = planetsData.find(p => p.name === planetName);
        if (planetInfo) {
          setShowSunPoem(false);
          setSelectedPlanet(planetInfo);
        }
      }
    };

    window.addEventListener('click', onClick);

    // Handle window resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation
    let time = 0;
    const animate = () => {
      requestAnimationFrame(animate);
      time += 0.01;

      // Rotate starfield slowly
      stars.rotation.y += 0.00005;
      nebula.rotation.y += 0.00003;
      nebula.rotation.x += 0.00002;

      // Sun rotation and pulsing
      sun.rotation.y += 0.001;
      const sunScale = 1 + Math.sin(time * 2) * 0.02;
      sun.scale.set(sunScale, sunScale, sunScale);

      // Planet orbits and rotations
      planets.forEach((planet, i) => {
        const data = planetsData[i];
        const group = planetGroups[i];

        group.rotation.y += data.orbitSpeed;
        planet.rotation.y += data.rotationSpeed;

        // Subtle bobbing motion
        planet.position.y = Math.sin(time + i) * 0.1;
      });

      // Camera orbit
      const cameraRadius = 85;
      const cameraSpeed = 0.05;
      camera.position.x = Math.sin(time * cameraSpeed) * cameraRadius;
      camera.position.z = Math.cos(time * cameraSpeed) * cameraRadius;
      camera.position.y = 35 + Math.sin(time * 0.3) * 5;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    setTimeout(() => setIsLoaded(true), 500);
    animate();

    return () => {
      window.removeEventListener('click', onClick);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  const closeModal = () => {
    setSelectedPlanet(null);
    setShowSunPoem(false);
  };

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className="absolute inset-0" />

      {/* Title */}
      <div className={`absolute top-8 left-1/2 transform -translate-x-1/2 text-center transition-all duration-1000 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'}`}>
        <h1 className="title-font text-4xl md:text-5xl lg:text-6xl text-white glow-text tracking-wider">
          Birthday Wishes
        </h1>
        <p className="poem-font text-lg md:text-xl text-gray-300 mt-2 tracking-wide">
          Click the planets to discover heartfelt messages
        </p>
      </div>

      {/* Instruction hint */}
      <div className={`absolute bottom-8 left-1/2 transform -translate-x-1/2 transition-all duration-1000 delay-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
        <p className="text-gray-400 text-sm poem-font italic">
          Explore the solar system... each celestial body holds a message for you
        </p>
      </div>

      {/* Poem Modal */}
      {(selectedPlanet || showSunPoem) && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          onClick={closeModal}
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div
            className="poem-container relative max-w-lg w-full rounded-2xl p-8 md:p-12 transform transition-all duration-500"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>

            <div className="text-center">
              <h2 className="title-font text-2xl md:text-3xl text-amber-200 mb-6 tracking-wide">
                {showSunPoem ? 'The Sun' : selectedPlanet?.name}
              </h2>
              <div className="h-px w-24 bg-gradient-to-r from-transparent via-amber-400/50 to-transparent mx-auto mb-6" />
              <p className="poem-font text-xl md:text-2xl text-gray-200 leading-relaxed whitespace-pre-line tracking-wide">
                {showSunPoem ? sunPoem : selectedPlanet?.poem}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
